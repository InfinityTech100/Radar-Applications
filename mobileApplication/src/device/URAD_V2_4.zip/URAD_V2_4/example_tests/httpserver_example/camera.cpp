/**
 * @file camera.h
 * @author Nader Hany (naderhany638@gmail.com)
 * @brief this file used to store videos on sd card
 *        for esp32-cam
 * @version 0.1
 * @date 2023-07-15
 * 
 * @copyright Copyright (c) 2023
 * 
 */

#include "camera.h"

camera::camera(/* args */)
{
}

camera::~camera()
{
}